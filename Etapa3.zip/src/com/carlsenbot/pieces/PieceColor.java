/*
 * © 2020 Grama Nicolae, Ioniță Radu , Mosessohn Vlad, 322CA
 */
package com.carlsenbot.pieces;

public enum PieceColor {
    White, Black
}
